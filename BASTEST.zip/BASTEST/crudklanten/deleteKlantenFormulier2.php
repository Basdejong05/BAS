<!doctype html>
<html>
	<head>
		<title>delete klanten formulier 2</title>
	</head>
	<body>
		<h1>delete klanten formulier 2</h1>
		
		<?php
			require "Klanten.php";					// nodig om object te maken
			$klantid = $_POST["klantidVak"];	// uitlezen vakje van deleteLeverancierForm1 
			$student1 = new Klanten();				// object aanmaken
			$student1->searchKlanten($klantid);
		?>
		
		<form action="deleteKlantenFormulier3.php" method="post">
			<!-- $klantid mag niet meer gewijzigd worden -->
			<input type="hidden" name="klantenIdVak" value=" <?php echo $klantid ?> ">
			<!-- 2x verwijderBox om nee of ja door te kunnen geven -->
			<input type="hidden" 	name="verwijderBox" value="nee">			
			<input type="checkbox" 	name="verwijderBox" value="ja">
			<label for="verwijderBox"> Verwijder deze klanten.</label><br/><br/>
			<input type="submit"><br/><br/>
		</form>

		<a href="klantenmenu.html">Terug naar het hoofdmenu</a>
	</body>	