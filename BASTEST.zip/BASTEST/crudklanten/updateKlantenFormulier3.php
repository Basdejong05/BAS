<!doctype html>
<html>
	
	<head>
		<title>update leverancier formulier 3</title>
	</head>
	<body>
		<h1>update leverancier formulier 3</h1>
		
		<?php
			require "Klanten.php";

            // gegevens uit de array in variabelen stoppen
		    $klantid = $_POST["klantenIdVak"];
			$naam = $_POST["klantnaamVak"];
			$email = $_POST["klantemailVak"];
			$adres = $_POST["klantadresVak"];
            $postcode = $_POST["klantpostcodeVak"];
            $woonplaats = $_POST["klantwoonplaatsVak"];
			
            // maken object ---------------------------------------------------
			$leverancier1 = new Klanten($naam, $email , $adres, $postcode , $woonplaats); // maakt object
			$leverancier1->updateKlanten($klantid);		           // vervangt de tabelgegevens voor objectgegevens
            echo "Dit zijn de gewijzigde gegevens: <br/>";
            echo $klantid."<br/>";
			$leverancier1->afdrukken();	                       // drukt object af

		?>
		<a href="leveranciermenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>