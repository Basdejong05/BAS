<!doctype html>
<html>
<head>




</head>
<body>
<h1>Delete klanten</h1>
<form action="deleteKlantenFormulier2.php" method="post">
    <label for="klantid">klantid:</label>
    <input type="submit">
    <select id="klantid" name="klantidVak">
    <?php
    
			include "LeverancierConnect.php";
			
			$sql = "SELECT klantid, klantnaam FROM klanten";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["klantid"] . "'>" . $row["klantid"] . " - ". $row["klantnaam"] . "</option>";
				}
			  } else {
				echo "geen artikelen gevonden";
			  }


			
			?>
</form>









</body>













</html>