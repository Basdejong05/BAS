<!doctype html>
<html>
	<head>
		<title>createS medewerker Formulier1</title>
	</head>
	<body>
		<h1>create medewerker formulier 1</h1>
		<form action="createMedewerkerFormulier2.php" method="post">
			<label for "naamvak">naam: </label>
			<input type = "text" name = "naamvak"></input>
			<br/>
			<label for "emailvak">email: </label>
			<input type = "text" name = "emailvak"></input>
			<br/>
			<label for "passwordvak">password: </label>
			<input type = "text" name = "passwordvak"></input>
			<br/>
			<label for "statusvak">status: </label>
			<input type = "text" name = "statusvak"></input>
			<br/>
			<input type="submit">
		</form>
	</body>
</html>