<!doctype html>
<html>
<head>
    <title>Read leverancieren</title>
</head>
<body>
<h1>Read leverancieren</h1>
<p></p>

<?php
    require "Medewerker.php";
    $medewerker1 = new Medewerker();
    $medewerker1->readMedewerker();



?>
<a href="medewerkermenu.html">Terug naar het hoofdmenu</a>
</body>








</html>