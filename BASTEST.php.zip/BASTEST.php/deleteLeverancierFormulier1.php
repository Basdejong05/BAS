<!doctype html>
<html>
<head>




</head>
<body>
<h1>Delete Leverancier</h1>
<form action="deleteLeverancierFormulier2.php" method="post">
    <label for="leverancierid">Leverancierid:</label>
    <input type="text" id="leverancierid" name="leverancierIdVak">
    <input type="submit">
</form>









</body>













</html>