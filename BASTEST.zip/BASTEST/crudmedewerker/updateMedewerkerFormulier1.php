<!doctype html>
<html>
	<head>
		<title>update klanten Formulier 1</title>
	</head>
	<body>
		<h1>update klanten formulier 1</h1>
			<form action="updateMedewerkerFormulier2.php" method="post">
			<label for="mwid">mwid:</label>
			<select id="mwid" name="mwidVak">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT mwid, mwNaam FROM medewerkers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["mwid"] . "'>" . $row["mwid"] . " - ". $row["mwNaam"] . "</option>";
				}
			  } else {
				echo "geen medewerkers gevonden";
			  }


			
			?>
			</select>

			<input type="submit">
		</form>
		<a href="medewerkermenu.html"><br/>Terug naar het hoofdmenu</a>
	</body>
