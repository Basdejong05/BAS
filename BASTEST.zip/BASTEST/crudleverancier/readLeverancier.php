<!doctype html>
<html>
<head>
    <title>Read leverancieren</title>
</head>
<body>
<h1>Read leverancieren</h1>
<p></p>

<?php
    require "Leverancier.php";
    $student1 = new Leverancier();
    $student1->readLeverancier();



?>
<a href="leveranciermenu.html">Terug naar het hoofdmenu</a>
</body>








</html>