<!doctype html>
<html>
	<head>
		<title>delete Medewerker formulier 3</title>
	</head>
	<body>
		<h1>delete Medewerker formulier 3</h1>
		
		<?php
			require "Medewerker.php";

		    $mwid = $_POST["MedewerkerIdVak"];
			$verwijderen = $_POST["verwijderBox"];
			
			if ($verwijderen=="ja")
			{
				echo "De medewerker is verwijderd <br/>";
				$medewerker1 =  new Medewerker();
				$medewerker1->deleteMedewerker($mwid);
			}
			else
			{
				echo "De medewerker is niet verwijderd <br/>";
			}
		?>
		<a href="medewerkermenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>
