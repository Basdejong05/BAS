<!doctype html>
<html>
    <head>
        <title>Search 2</title>
    </head>
    <body>
        <h1>Search 2</h1>
        <?php 
        require "Medewerker.php";
        $mwid = $_POST["mwidVak"];
        $medewerker1 = new Medewerker();
        $medewerker1->searchmedewerker($mwid);
        ?>
        <br>
        <a href="medewerkermenu.html">Terug naar het hoofdmenu</a>











    </body>
</html>