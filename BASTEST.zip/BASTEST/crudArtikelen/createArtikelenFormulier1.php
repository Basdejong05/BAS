<!doctype html>
<html>
	<head>
		<title>create Artikelen Formulier1</title>
	</head>
	<body>
		<h1>create Artikelen formulier 1</h1>
		<form action="createArtikelenFormulier2.php" method="post">
			<label for "artikelOmschrijvingvak">ArtikelOmschrijving: </label>
			<input type = "text" name = "artOmschrijvingvak"></input>
			<br/>
			<label for "artikelInkoopvak">Artikel inkoop: </label>
			<input type = "text" name = "artInkoopvak"></input>
			<br/>
			<label for "artikelVerkoopvak">Artikel verkoop: </label>
			<input type = "text" name = "artVerkoopvak"></input>
			<br/>
			<label for "artikelVoorraadvak">Artikel voorraad: </label>
			<input type = "text" name = "artVoorraadvak"></input>
			<br/>
			<label for "artikelMinimumvoorraadvak">Artikel minimum voorraad: </label>
			<input type = "text" name = "artMinvoorraadvak"></input>
			<br/>
            <label for "artikelMaximumvoorraadvak">Artikel maximum voorraad: </label>
			<input type = "text" name = "artMaxvoorraadvak"></input>
			<br/>
			<label for "artikelLocatievak">Artikel Locatie: </label>
			<input type = "text" name = "artLocatievak"></input>
			<br/>
			<label for "artLevid">leverancier id: </label>
			<!-- <input type = "text" name = "artLevid"></input>  -->
			<select id="artLevid" name="artLevid">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT levid, levnaam FROM leveranciers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["levid"] . "'>" . $row["levid"] . " - ". $row["levnaam"] . "</option>";
				}
			  } else {
				echo "geen leveranciers gevonden";
			  }


			
			?>
			</select>



			<br/>
			<input type="submit">
		</form>
	</body>
</html>