<!doctype html>
<html>
	
	<head>
		<title>update leverancier formulier 3</title>
	</head>
	<body>
		<h1>update leverancier formulier 3</h1>
		
		<?php
			require "Medewerker.php";

            // gegevens uit de array in variabelen stoppen
		    $mwid = $_POST["medewerkerIdVak"];
			$naam = $_POST["medewerkernaamVak"];
			$email = $_POST["medewerkeremailVak"];
			$password = $_POST["medewerkerpasswordVak"];
            $status = $_POST["medewerkerstatusVak"];

			
            // maken object ---------------------------------------------------
			$leverancier1 = new Medewerker($naam, $email , $password, $status); // maakt object
			$leverancier1->updateMedewerker($mwid);		           // vervangt de tabelgegevens voor objectgegevens
            echo "Dit zijn de gewijzigde gegevens: <br/>";
            echo $mwid."<br/>";
			$leverancier1->afdrukken();	                       // drukt object af

		?>
		<a href="medewerkermenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>