<!doctype html>
<html>
<head>




</head>
<body>
<h1>Delete Leverancier</h1>
<form action="deleteLeverancierFormulier2.php" method="post">
    <label for="levid">levid:</label>
    <input type="submit">
    <select id="levid" name="levidVak">
    <?php
    
			include "LeverancierConnect.php";
			
			$sql = "SELECT levid, levnaam FROM leveranciers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["levid"] . "'>" . $row["levid"] . " - ". $row["levnaam"] . "</option>";
				}
			  } else {
				echo "geen leveranciers gevonden";
			  }


			
			?>
</form>









</body>













</html>