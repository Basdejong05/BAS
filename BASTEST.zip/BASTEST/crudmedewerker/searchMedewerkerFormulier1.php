<!doctype html>
<html>
<head>




</head>
<body>
<form action="searchMedewerkerFormulier2.php" method="post">
			<label for="mwid">mwid:</label>
			

			<select id="mwid" name="mwidVak">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT mwid, mwNaam FROM medewerkers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["mwid"] . "'>" . $row["mwid"] . " - ". $row["mwNaam"] . "</option>";
				}
			  } else {
				echo "geen medewerkers gevonden";
			  }


			
			?>
			</select>

			<input type="submit">

</body>

