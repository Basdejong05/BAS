<!doctype html>
<html>
	<head>
		<title>update leverancier Formulier 1</title>
	</head>
	<body>
		<h1>update leverancier formulier 1</h1>
			<form action="updateLeverancierFormulier2.php" method="post">
			<label for="levid">levid:</label>
			

			<select id="levid" name="levidVak">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT levid, levnaam FROM leveranciers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["levid"] . "'>" . $row["levid"] . " - ". $row["levnaam"] . "</option>";
				}
			  } else {
				echo "geen artikelen gevonden";
			  }


			
			?>
			</select>

			<input type="submit">
		</form>
		<a href="leveranciermenu.html"><br/>Terug naar het hoofdmenu</a>
	</body>
