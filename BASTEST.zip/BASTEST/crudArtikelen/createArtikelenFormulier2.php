<!doctype html>
<html>
	<head>
		<title>create artikel formulier 2</title>
	</head>
	<body>
		<h1>create artikel formulier 2</h1>

		<?php
			require "Artikelen.php";
			
			// uitlezen vakjes van createLeverancierForm1 -----
			$artOmschrijving=$_POST["artOmschrijvingvak"];
			$artInkoop=$_POST["artInkoopvak"];
			$artVerkoop=$_POST["artVerkoopvak"];
			$artVoorraad=$_POST["artVoorraadvak"];
			$artMinvoorraad=$_POST["artMinvoorraadvak"];
			$artMaxvoorraad=$_POST["artMaxvoorraadvak"];
            $artLocatie=$_POST["artLocatievak"];
            $artLeverancierid=$_POST["artLevid"];

			// maken object -------------------------------
			$artikel1 = new Artikelen($artOmschrijving , $artInkoop , $artVerkoop ,$artVoorraad, $artMinvoorraad, $artMaxvoorraad, $artLocatie, $artLeverancierid);
            $artikel1->createArtikel();

			// afdrukken object ---------------------------
		
			echo "<br/><br/>";
			echo $artikel1->afdrukken();
		?> 	
		<br>
		<a href="artikelenmenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>
