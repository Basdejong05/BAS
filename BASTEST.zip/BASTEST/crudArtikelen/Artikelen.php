<?php

require "LeverancierConnect.php";
class Artikelen
{
    //properties
    public $artOmschrijving;
    public $artInkoop;
    public $artVerkoop;
    public $artVoorraad;
    public $artMinvoorraad;

    public $artMaxvoorraad;
    public $artLocatie;
    public $artLevid;

    //constructor
    function __construct($artOmschrijving = NULL, $artVoorraad = NULL, $artVerkoop = NULL, $artInkoop = NULL, $artMinvoorraad = NULL, $artMaxvoorraad = NULL , $artLocatie = NULL, $artLevid = NULL)
    {

        $this->artOmschrijving = $artOmschrijving;
        $this->artVoorraad = $artVoorraad;
        $this->artVerkoop = $artVerkoop;
        $this->artInkoop = $artInkoop;
        $this->artMinvoorraad = $artMinvoorraad;
        $this->artMaxvoorraad = $artMaxvoorraad;
        $this->artLocatie = $artLocatie;
        $this->artLevid = $artLevid;
        
        
    }

    //setters
    function set_artVerkoop($artVerkoop)
    {
        $this->artVerkoop = $artVerkoop;
    }

    

    function set_artOmschrijving($artOmschrijving){
        $this->artOmschrijving = $artOmschrijving;
    }

    function set_artInkoop($artInkoop){
        $this->artInkoop = $artInkoop;
    }

    function set_artVoorraad($artVoorraad)
    {
        $this->artVoorraad = $artVoorraad;
    }

    function set_artMinvoorraad($artMinvoorraad)
    {
        $this->artMinvoorraad = $artMinvoorraad;
    }

    function set_artMaxvoorraad($artMaxvoorraad)
    {
        $this->artMaxvoorraad = $artMaxvoorraad;
    }

    function set_artLocatie($artLocatie)
    {
        $this->artLocatie = $artLocatie;
    }


    //getters

    function get_artOmschrijving(){
        return $this->artOmschrijving;
    }
    function get_levid(){
        return $this->artLevid;
    }

    

    function get_artInkoop(){
        return $this->artInkoop;
    }

    function get_artVoorraad()
    {
        return $this->artVoorraad;
    }
    function get_artMinvoorraad()
    {
        return $this->artMinvoorraad;
    }

    function get_artMaxvoorraad()
    {
        return $this->artMaxvoorraad;
    }

    function get_artVerkoop()
    {
        return $this->artVerkoop;
    }

    function get_artLocatie()
    {
        return $this->artLocatie;
    }





    // functies voor crud

    
    public function afdrukken()
		{
			echo "Omschrijving : ". $this->get_artOmschrijving();
			echo "<br/>";
            echo "Inkoopprijs: €" . $this->get_artInkoop();
            echo "<br/>";
            echo "Verkoopprijs: €" . $this->get_artVerkoop();
			echo "<br/>";
            echo "Aantal Voorraad: " . $this->get_artVoorraad();
            echo "<br/>";
            echo "Minimale Voorraad: " . $this->get_artMinvoorraad();
            echo "<br/>";
            echo "Maximale Voorraad: " . $this->get_artMaxvoorraad();
            echo "<br/>";
            echo "Artikel Locatie rij: " . $this->get_artLocatie();
            echo "<br/>";
            echo "Leveranvier id: " . $this->get_levid();
            echo "<br/>";

		}

    public function createArtikel(){
        $artId = NULL;
        $artlevid = $this->get_levid();
        $artOmschrijving = $this->get_artOmschrijving();
        $artVoorraad = $this->get_artVoorraad();
        $artVerkoop = $this->get_artVerkoop();
        $artMinvoorraad = $this->get_artMinvoorraad();
        $artInkoop = $this->get_artInkoop();
        $artMaxvoorraad = $this->get_artMaxvoorraad();
        $artLocatie = $this->get_artLocatie();
        global $conn;

        $sql = $conn->prepare("INSERT INTO `artikelen`(`artId`, `artOmschrijving`, `artInkoop`, `artVerkoop`, `artVoorraad`, `artMinVoorraad`, `artMaxVoorraad`, `artLocatie`, `fk_levid`) VALUES (:artId, :artOmschrijving, :artInkoop, :artVerkoop, :artVoorraad, :artMinvoorraad, :artMaxvoorraad, :artLocatie, :fk_levid)");
        //$sql = $conn->Prepare("INSERT INTO artikelen VALUES(:artId, :artOmschrijving, :artInkoop, :artVerkoop, :artVoorraad, :artMinvoorraad, :artMaxvoorraad , :artLocatie, :levid");
        $sql->execute([
            "artId" => $artId,
            "artOmschrijving" => $artOmschrijving,
            "artInkoop" => $artInkoop,
            "artVerkoop" => $artVerkoop,
            "artVoorraad" => $artVoorraad,
            "artMinvoorraad" => $artMinvoorraad,
            "artMaxvoorraad" => $artMaxvoorraad,
            "artLocatie" => $artLocatie,
            "fk_levid" => $artlevid,
        ]);
        echo"de artikelen is toegevoegd";
    }

    public function readartikelen(){
        global $conn;
        $sql = $conn->Prepare(" SELECT * FROM artikelen
        
        
        ");

        $sql->execute();
        foreach($sql as $artikelen)
        {
            echo "Artikel id: " . $artikelen ["artId"] . " - ";
            echo "Omschrijving : ". $this->artOmschrijving= $artikelen ["artOmschrijving"]. " - ";
            echo "Inkoopprijs: €" . $this->artVoorraad= $artikelen ["artInkoop"]. " - ";
            echo "Verkoopprijs: €" . $this->artVerkoop= $artikelen ["artVerkoop"]. " - ";
            echo "Aantal Voorraad: " . $this->artVoorraad= $artikelen ["artVoorraad"]. " - ";
            echo "Minimale Voorraad: " . $this->artMinvoorraad= $artikelen ["artMinVoorraad"]. " - ";
            echo "Maximale Voorraad: " . $this->artMaxvoorraad= $artikelen ["artMaxVoorraad"]. " - ";
            echo "Artikel Locatie rij: " . $this->artLocatie= $artikelen ["artLocatie"]. " - ";
            echo "Leveranvier id: " . $this->artLevid = $artikelen ["fk_levid"]. "<br>";
        }

    }
    public function searchArtikelen($artId){
        require "LeverancierConnect.php";
        $sql = $conn->Prepare("SELECT * FROM artikelen WHERE artId = :artId  ");
        $sql->bindParam(":artId", $artId);
        $sql->execute();

        foreach($sql as $artikelen){
            echo "Artikel id: " . $artikelen["artId"] . "<br>";
            echo "Artikel omschrijving: " . $artikelen["artOmschrijving"] . "<br>";

            $this->artOmschrijving=$artikelen["artOmschrijving"];

            echo "Inkoopprijs: €" . $artikelen["artInkoop"] . "<br>";

            $this->artVoorraad=$artikelen["artInkoop"];

            echo "Verkoopprijs: €" . $artikelen["artVerkoop"] . "<br>";
 
            $this->artVerkoop=$artikelen["artVerkoop"];

            echo "Aantal Voorraad: " . $artikelen["artVoorraad"] . "<br>";

            $this->artMinvoorraad=$artikelen["artVoorraad"];

            echo "Minimale Voorraad: " . $artikelen["artMinVoorraad"] . "<br>";

            $this->artInkoop=$artikelen["artMinVoorraad"];

            echo "Maximale Voorraad: " . $artikelen["artMaxVoorraad"] . "<br>";

            $this->artMaxvoorraad=$artikelen["artMaxVoorraad"];

            echo "Artikel Locatie rij: " .  $artikelen["artLocatie"] . "<br>";

            $this->artLocatie=$artikelen["artLocatie"];
            echo "Leveranvier id: " . $artikelen["fk_levid"];
            $this->artLevid = $artikelen["fk_levid"];
            

        }
    }
    public function deleteartikelen($artId)
		{
			require "LeverancierConnect.php";
			// statement maken
			$sql = $conn->prepare("
									delete from artikelen
									where artId = :artId
								 ");
			// variabele in de statement zetten
			$sql->bindParam(":artId", $artId);
			$sql->execute();
		}

        public function updateartikelen($artId)
		{
			require "LeverancierConnect.php";
			// gegevens uit het object in variabelen zetten 
			$artId;
			$artOmschrijving 		= $this->get_artOmschrijving();
            $artVoorraad    = $this->get_artVoorraad();
            $artVerkoop      = $this->get_artVerkoop();
            $artMinvoorraad      = $this->get_artMinvoorraad();
            $artInkoop 	= $this->get_artInkoop();
            $artMaxvoorraad = $this->get_artMaxvoorraad();
            $artLocatie = $this->get_artLocatie();
            $artLevid = $this->get_levid();

			// statement maken
			$sql = $conn->prepare("
									update artikelen
									set artOmschrijving=:artOmschrijving, artInkoop=:artInkoop, artVerkoop=:artVerkoop, artVoorraad=:artVoorraad , artMinvoorraad=:artMinvoorraad , artMaxvoorraad=:artMaxvoorraad , artLocatie=:artLocatie , fk_levid=:fk_levid
									where artId=:artId
								 ");
			// variabelen in de statement zetten
			$sql->bindParam(":artId", $artId);
			$sql->bindParam(":artOmschrijving", $artOmschrijving);
			$sql->bindParam(":artInkoop", $artVoorraad);
			$sql->bindParam(":artVerkoop", $artVerkoop);
            $sql->bindParam(":artVoorraad", $artMinvoorraad);
            $sql->bindParam(":artMinvoorraad", $artInkoop);
            $sql->bindParam(":artMaxvoorraad", $artMaxvoorraad);
            $sql->bindParam(":artLocatie", $artLocatie);
            $sql->bindParam(":fk_levid", $artLevid);

			$sql->execute();
		}

}












?>