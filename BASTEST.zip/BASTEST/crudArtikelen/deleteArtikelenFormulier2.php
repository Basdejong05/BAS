<!doctype html>
<html>
	<head>
		<title>delete klanten formulier 2</title>
	</head>
	<body>
		<h1>delete klanten formulier 2</h1>
		
		<?php
			require "Artikelen.php";					// nodig om object te maken
			$artId = $_POST["artikelIdVak"];	// uitlezen vakje van deleteLeverancierForm1 
			$student1 = new Artikelen();				// object aanmaken
			$student1->searchArtikelen($artId);
		?>
		
		<form action="deleteArtikelenFormulier3.php" method="post">
			<!-- $artId mag niet meer gewijzigd worden -->
			<input type="hidden" name="artikelIdVak" value=" <?php echo $artId ?> ">
			<!-- 2x verwijderBox om nee of ja door te kunnen geven -->
			<input type="hidden" 	name="verwijderBox" value="nee">			
			<input type="checkbox" 	name="verwijderBox" value="ja">
			<label for="verwijderBox"> Verwijder deze artikel.</label><br/><br/>
			<input type="submit"><br/><br/>
		</form>

		<a href="artikelmenu.html">Terug naar het hoofdmenu</a>
	</body>	