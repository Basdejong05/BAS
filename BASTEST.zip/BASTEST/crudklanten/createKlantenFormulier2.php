<!doctype html>
<html>
	<head>
		<title>create klanten formulier 2</title>
	</head>
	<body>
		<h1>create klanten formulier 2</h1>

		<?php
			require "klanten.php";
			
			// uitlezen vakjes van createklantenForm1 -----
			$naam=$_POST["naamvak"];
			$email=$_POST["emailvak"];
			$adres=$_POST["adresvak"];
			$postcode=$_POST["postcodevak"];
			$woonplaats=$_POST["woonplaatsvak"];

			// maken object -------------------------------
			$klant1 = new klanten($naam ,$email, $adres, $postcode, $woonplaats);
            $klant1->createKlanten();

			// afdrukken object ---------------------------
		
			echo "<br/><br/>";
			echo $klant1->afdrukken();
		?> 	
		<br>
		<a href="klantenmenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>
