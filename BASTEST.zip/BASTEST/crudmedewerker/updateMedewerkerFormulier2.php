<!doctype html>
<html>
	<head>
		<title>update medewerker formulier 2</title>
	</head>
	<body>
		<h1>update medewerker formulier 2</h1>
		
		<?php
			require "medewerker.php";					// nodig om object te maken
			$mwid = $_POST["mwidVak"];	// uitlezen vakje van deletemedewerkerForm1 
			$medewerker1 = new medewerker();				// object aanmaken
			$medewerker1->searchmedewerker($mwid);	
			// properties in variabelen zetten
			$naam=$medewerker1->get_name();
			$email=$medewerker1->get_email();
			$password=$medewerker1->get_password();
			$status=$medewerker1->get_status();

		?>
		
		<form action="updateMedewerkerFormulier3.php" method="post">
			<!-- $mwid mag niet meer gewijzigd worden -->
			<br>
            <?php echo $mwid ?>
            <input type="hidden" name="medewerkerIdVak" value="<?php echo $mwid;  ?> "><br>
			<label for="medewerkernaamVak">Naam:</label>
            <input type="text"   name="medewerkernaamVak"      value="<?php echo $naam;     ?> "><br/>
			<label for="medewerkeremailVak">Email:</label>
			<input type="text"   name="medewerkeremailVak"  value="<?php echo $email;  ?> "><br/>
			<label for="medewerkerpassword">Password:</label>
            <input type="text"   name="medewerkerpasswordVak"      value="<?php echo $password;     ?> "><br/>
			<label for="medewerkerstatusVak">status:</label>
            <input type="text"   name="medewerkerstatusVak"  value="<?php echo $status;  ?> "><br/>
			<input type="submit"><br/><br/>
		</form>

		<a href="medewerkermenu.html">Terug naar het hoofdmenu</a>
	</body>	