<!doctype html>
<html>
	<head>
		<title>delete klanten formulier 3</title>
	</head>
	<body>
		<h1>delete klanten formulier 3</h1>
		
		<?php
			require "Klanten.php";

		    $klantid = $_POST["klantenIdVak"];
			$verwijderen = $_POST["verwijderBox"];
			
			if ($verwijderen=="ja")
			{
				echo "De klant is verwijderd <br/>";
				$klant1 =  new klanten();
				$klant1->deleteklanten($klantid);
			}
			else
			{
				echo "De klant is niet verwijderd <br/>";
			}
		?>
		<a href="klantenmenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>
