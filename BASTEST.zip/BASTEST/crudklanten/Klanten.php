<?php 

require "LeverancierConnect.php";
class Klanten
{
    //properties
    public $naam;
    public $postcode;
    public $email;
    public $contact;
    public $adres;

    public $woonplaats;

    //constructor
    function __construct($naam = NULL, $email = NULL, $adres = NULL, $postcode = NULL, $woonplaats = NULL )
    {

        $this->naam = $naam;
        $this->email = $email;
        $this->adres = $adres;
        $this->postcode = $postcode;
        $this->woonplaats = $woonplaats;
        
    }

    //setters
    function set_email($email)
    {
        $this->email = $email;
    }



    function set_name($naam){
        $this->naam = $naam;
    }

    function set_postcode($postcode){
        $this->postcode = $postcode;
    }

    function set_adres($adres)
    {
        $this->adres = $adres;
    }

    function set_woonplaats($woonplaats)
    {
        $this->woonplaats = $woonplaats;
    }

    //getters

    function get_name(){
        return $this->naam;
    }

    function get_postcode(){
        return $this->postcode;
    }

    function get_adres()
    {
        return $this->adres;
    }

    function get_woonplaats()
    {
        return $this->woonplaats;
    }

    function get_email()
    {
        return $this->email;
    }






    // functies voor crud

    
    public function afdrukken()
		{
			echo "klant naam: " . $this->get_name();
			echo "<br/>";
            echo "klant email: " . $this->get_email();
            echo "<br/>";
            echo "klant adres: " . $this->get_adres();
            echo "<br/>";
            echo "klant postcode: " . $this->get_postcode();
            echo "<br/>";
            echo "klant woonplaats: " . $this->get_woonplaats();
            echo "<br/>";

		}

    public function createKlanten(){
        $klantid = NULL;
        $naam = $this->get_name();
        $email = $this->get_email();
        $adres = $this->get_adres();
        $postcode = $this->get_postcode();
        $woonplaats = $this->get_woonplaats();
        global $conn;

        $sql = $conn->Prepare("INSERT INTO klanten VALUES(:klantid, :klantnaam, :klantEmail, :klantAdres, :klantPostcode, :klantWoonplaats)");
        $sql->execute([
            "klantid" => $klantid,
            "klantnaam" => $naam,
            "klantEmail" => $email,
            "klantAdres" => $adres,
            "klantPostcode" => $postcode,
            "klantWoonplaats" => $woonplaats,
        ]);
        echo"de klanten is toegevoegd";
    }

    public function readKlanten(){
        global $conn;
        $sql = $conn->Prepare(" SELECT * FROM klanten
        
        
        ");

        $sql->execute();
        foreach($sql as $klanten)
        {
            echo "klant id: " . $klanten ["klantid"] . " - ";
            echo "klant naam: " . $this->naam= $klanten ["klantnaam"]. " - ";
            echo "klant email: " . $this->email= $klanten ["klantEmail"]. " - ";
            echo "klant adres: " . $this->adres= $klanten ["klantAdres"]. " - ";
            echo "klant postcode: " . $this->postcode= $klanten ["klantPostcode"]. " - ";
            echo "klant woonplaats: " . $this->woonplaats = $klanten ["klantWoonplaats"]. "<br>";
        }

    }
    public function searchKlanten($klantid){
        require "LeverancierConnect.php";
        $sql = $conn->Prepare("SELECT * FROM klanten WHERE klantid = :klantid");
        $sql->bindParam(":klantid", $klantid);
        $sql->execute();

        foreach($sql as $klanten){
            echo "klant id: " . $klanten["klantid"] . "<br>";
            echo "klant naam: " . $klanten["klantnaam"] . "<br>";
            $this->naam=$klanten["klantnaam"];
            echo "klant email: " . $klanten["klantEmail"] . "<br>";
            $this->email=$klanten["klantEmail"];
            echo "klant adres: " . $klanten["klantAdres"] . "<br>";
            $this->adres=$klanten["klantAdres"];
            echo "klant postcode: " . $klanten["klantPostcode"] . "<br>";
            $this->postcode=$klanten["klantPostcode"];
            echo "klant woonplaats: " . $klanten["klantWoonplaats"] . "<br>";
            $this->woonplaats=$klanten["klantWoonplaats"];

        }
    }
    public function deleteKlanten($klantid)
		{
			require "LeverancierConnect.php";
			// statement maken
			$sql = $conn->prepare("
									delete from klanten
									where klantid = :klantid
								 ");
			// variabele in de statement zetten
			$sql->bindParam(":klantid", $klantid);
			$sql->execute();
		}

        public function updateKlanten($klantid)
		{
			require "LeverancierConnect.php";
			// gegevens uit het object in variabelen zetten 
			$klantid;
			$naam 		= $this->get_name();
            $email      = $this->get_email();
            $adres      = $this->get_adres();
            $postcode 	= $this->get_postcode();
            $woonplaats = $this->get_woonplaats();

			// statement maken
			$sql = $conn->prepare("
									update klanten
									set klantnaam=:klantnaam, klantEmail=:klantEmail, klantAdres=:klantAdres , klantPostcode=:klantPostcode , klantWoonplaats=:klantWoonplaats 
									where klantid=:klantid
								 ");
			// variabelen in de statement zetten
			$sql->bindParam(":klantid", $klantid);
			$sql->bindParam(":klantnaam", $naam);
			$sql->bindParam(":klantEmail", $email);
            $sql->bindParam(":klantAdres", $adres);
            $sql->bindParam(":klantPostcode", $postcode);
            $sql->bindParam(":klantWoonplaats", $woonplaats);
			$sql->execute();
		}

}












?>