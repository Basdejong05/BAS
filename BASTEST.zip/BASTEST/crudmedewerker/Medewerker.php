<?php 

require "LeverancierConnect.php";
class Medewerker
{
    //properties
    public $naam;
    public $email;

    public $password;

    public $status;
    //constructor
    function __construct($naam = NULL, $email = NULL, $password = NULL, $status = NULL )
    {

        $this->naam = $naam;
        $this->email = $email;
        $this->password = $password;
        $this->status = $status;
        
    }

    //setters


    function set_name($naam){
        $this->naam = $naam;
    }

    function set_email($email){
        $this->email = $email;
    }

    function set_password($password)
    {
        $this->password = $password;
    }

    function set_status($status)
    {
        $this->status = $status;
    }

    //getters

    function get_name(){
        return $this->naam;
    }

    function get_email(){
        return $this->email;
    }

    function get_password()
    {
        return $this->password;
    }

    function get_status()
    {
        return $this->status;
    }






    // functies voor crud

    
    public function afdrukken()
		{
			echo "medewerker naam: " . $this->get_name();
			echo "<br/>";
            echo "medewerker email: " . $this->get_email();
            echo "<br/>";
            echo "medewerker password: " . $this->get_password();
            echo "<br/>";
            echo "medewerker status: " . $this->get_status();
            echo "<br/>";

		}

    public function createMedewerker(){
        $mwid = NULL;
        $naam = $this->get_name();
        $email = $this->get_email();
        $password = $this->get_password();
        $status = $this->get_status();
        global $conn;

        $sql = $conn->Prepare("INSERT INTO medewerkers VALUES(:mwid, :mwNaam, :mwEmail, :mwPassword, :mwStatus)");
        $sql->execute([
            "mwid" => $mwid,
            "mwNaam" => $naam,
            "mwEmail" => $email,
            "mwPassword" => $password,
            "mwStatus" => $status,
        ]);
        echo"de medewerker is toegevoegd";
    }
    public function readMedewerker(){
        global $conn;
        $sql = $conn->Prepare(" SELECT * FROM medewerkers
        
        
        ");

        $sql->execute();
        foreach($sql as $medewerker)
        {
            echo "medewerker id: " . $medewerker ["mwid"] . " - ";
            echo "medewerker naam: " . $this->naam= $medewerker ["mwNaam"]. " - ";
            echo "medewerker email: " . $this->email= $medewerker ["mwEmail"]. " - ";
            echo "medewerker password: " . $this->password= $medewerker ["mwPassword"]. " - ";
            echo "medewerker status: " . $this->status = $medewerker ["mwStatus"]. "<br>";
        }

    }
    public function searchmedewerker($mwid){
        require "LeverancierConnect.php";
        $sql = $conn->Prepare("SELECT * FROM medewerkers WHERE mwid = :mwid");
        $sql->bindParam(":mwid", $mwid);
        $sql->execute();

        foreach($sql as $medewerkers){
            echo "medewerker id: " . $medewerkers["mwid"] . "<br>";
            echo "medewerker naam: " . $medewerkers["mwNaam"] . "<br>";
            $this->naam=$medewerkers["mwNaam"];
            echo "medewerker email: " . $medewerkers["mwEmail"] . "<br>";
            $this->email=$medewerkers["mwEmail"];
            echo "medewerker password: " . $medewerkers["mwPassword"] . "<br>";
            $this->password=$medewerkers["mwPassword"];
            echo "medewerker status: " . $medewerkers["mwStatus"] . "<br>";
            $this->status=$medewerkers["mwStatus"];


        }
    }
    public function deleteMedewerker($mwid)
    {
        require "LeverancierConnect.php";
        // statement maken
        $sql = $conn->prepare("
                                delete from medewerkers
                                where mwid = :mwid
                             ");
        // variabele in de statement zetten
        $sql->bindParam(":mwid", $mwid);
        $sql->execute();
    }
    public function updateMedewerker($mwid)
    {
        require "LeverancierConnect.php";
        // gegevens uit het object in variabelen zetten 
        $mwid;
        $naam 		= $this->get_name();
        $email      = $this->get_email();
        $password      = $this->get_password();
        $status 	= $this->get_status();

        // statement maken
        $sql = $conn->prepare("
                                update medewerkers 
                                set mwNaam=:mwNaam, mwEmail=:mwEmail, mwPassword=:mwPassword , mwStatus=:mwStatus 
                                where mwid=:mwid
                             ");
        // variabelen in de statement zetten
        $sql->bindParam(":mwid", $mwid);
        $sql->bindParam(":mwNaam", $naam);
        $sql->bindParam(":mwEmail", $email);
        $sql->bindParam(":mwPassword", $password);
        $sql->bindParam(":mwStatus", $status);
        $sql->execute();
    }

    
    
   
    

       

}












?>