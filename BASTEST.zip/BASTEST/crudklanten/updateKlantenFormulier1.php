<!doctype html>
<html>
	<head>
		<title>update klanten Formulier 1</title>
	</head>
	<body>
		<h1>update klanten formulier 1</h1>
			<form action="updateklantenFormulier2.php" method="post">
			<label for="klantenid">klantenid:</label>
			<!-- <input type="text" id = "klantenid" name="klantenIdVak"> -->

			<select id="klantenId" name="klantenIdVak">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT klantid, klantnaam FROM klanten";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["klantid"] . "'>" . $row["klantid"] . " - ". $row["klantnaam"] . "</option>";
				}
			  } else {
				echo "geen leveranciers gevonden";
			  }


			
			?>
			</select>

			<input type="submit">
		</form>
		<a href="schoolmenu.php"><br/>Terug naar het hoofdmenu</a>
	</body>
