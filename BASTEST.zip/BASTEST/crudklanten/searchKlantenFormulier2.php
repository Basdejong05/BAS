<!doctype html>
<html>
    <head>
        <title>Search 2</title>
    </head>
    <body>
        <h1>Search 2</h1>
        <?php 
        require "Klanten.php";
        $klantid = $_POST["klantenidVak"];
        $student1 = new Klanten();
        $student1->searchKlanten($klantid);
        ?>
        <br>
        <a href="klantenmenu.html">Terug naar het hoofdmenu</a>











    </body>
</html>