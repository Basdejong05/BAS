<!doctype html>
<html>
	<head>
		<title>update Leverancier Formulier 1</title>
	</head>
	<body>
		<h1>update leverancier formulier 1</h1>
			<form action="updateLeverancierFormulier2.php" method="post">
			<label for="leverancierid">Leverancierid:</label>
			<input type="text" id = "leverancierid" name="leverancierIdVak">
			<input type="submit">
		</form>
		<a href="schoolmenu.php"><br/>Terug naar het hoofdmenu</a>
	</body>
