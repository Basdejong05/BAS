<!doctype html>
<html>
<head>




</head>
<body>
<form action="searchKlantenFormulier2.php" method="post">
			<label for="klantenid">klantenid:</label>
			

			<select id="klantenid" name="klantenidVak">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT klantid, klantnaam FROM klanten";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["klantid"] . "'>" . $row["klantid"] . " - ". $row["klantnaam"] . "</option>";
				}
			  } else {
				echo "geen klanten gevonden";
			  }


			
			?>
			</select>

			<input type="submit">

</body>

