<!doctype html>
<html>
<head>




</head>
<body>
<form action="searchLeverancierFormulier2.php" method="post">
			<label for="levid">levid:</label>
			

			<select id="levid" name="levidVak">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT levid, levnaam FROM leveranciers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["levid"] . "'>" . $row["levid"] . " - ". $row["levnaam"] . "</option>";
				}
			  } else {
				echo "geen leveranciers gevonden";
			  }


			
			?>
			</select>

			<input type="submit">

</body>

