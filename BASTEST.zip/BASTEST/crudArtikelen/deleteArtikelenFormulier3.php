<!doctype html>
<html>
	<head>
		<title>delete klanten formulier 3</title>
	</head>
	<body>
		<h1>delete klanten formulier 3</h1>
		
		<?php
			require "Artikelen.php";

		    $artId = $_POST["artikelIdVak"];
			$verwijderen = $_POST["verwijderBox"];
			
			if ($verwijderen=="ja")
			{
				echo "Het artikel is verwijderd <br/>";
				$klant1 =  new Artikelen();
				$klant1->deleteartikelen($artId);
			}
			else
			{
				echo "Het artikel is niet verwijderd <br/>";
			}
		?>
		<a href="artikelenmenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>
