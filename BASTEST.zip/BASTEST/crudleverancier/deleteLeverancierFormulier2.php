<!doctype html>
<html>
	<head>
		<title>delete leverancier formulier 2</title>
	</head>
	<body>
		<h1>delete leverancier formulier 2</h1>
		
		<?php
			require "Leverancier.php";					// nodig om object te maken
			$levid = $_POST["levidVak"];	// uitlezen vakje van deleteLeverancierForm1 
			$student1 = new Leverancier();				// object aanmaken
			$student1->searchLeverancier($levid);
		?>
		
		<form action="deleteLeverancierFormulier3.php" method="post">
			<!-- $levid mag niet meer gewijzigd worden -->
			<input type="hidden" name="leverancierIdVak" value=" <?php echo $levid ?> ">
			<!-- 2x verwijderBox om nee of ja door te kunnen geven -->
			<input type="hidden" 	name="verwijderBox" value="nee">			
			<input type="checkbox" 	name="verwijderBox" value="ja">
			<label for="verwijderBox"> Verwijder deze leverancier.</label><br/><br/>
			<input type="submit"><br/><br/>
		</form>

		<a href="leveranciermenu.html">Terug naar het hoofdmenu</a>
	</body>	