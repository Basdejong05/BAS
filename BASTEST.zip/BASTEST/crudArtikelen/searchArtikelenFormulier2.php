<!doctype html>
<html>
    <head>
        <title>Seatch 2</title>
    </head>
    <body>
        <h1>Search 2</h1>
        <?php 
        require "Artikelen.php";
        $artId = $_POST["artikelIdVak"];
        $student1 = new Artikelen();
        $student1->searchArtikelen($artId);
        ?>
        <br>
        <a href="artikelenmenu.html">Terug naar het hoofdmenu</a>











    </body>
</html>