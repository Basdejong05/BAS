<!doctype html>
<html>
	<head>
		<title>createS klanten Formulier1</title>
	</head>
	<body>
		<h1>create klanten formulier 1</h1>
		<form action="createKlantenFormulier2.php" method="post">
			<label for "naamvak">naam: </label>
			<input type = "text" name = "naamvak"></input>
			<br/>
			<label for "emailvak">email: </label>
			<input type = "text" name = "emailvak"></input>
			<br/>
			<label for "adresvak">adres: </label>
			<input type = "text" name = "adresvak"></input>
			<br/>
			<label for "postcodevak">postcode: </label>
			<input type = "text" name = "postcodevak"></input>
			<br/>
			<label for "woonplaatsvak">woonplaats: </label>
			<input type = "text" name = "woonplaatsvak"></input>
			<br/>
			<input type="submit">
		</form>
	</body>
</html>