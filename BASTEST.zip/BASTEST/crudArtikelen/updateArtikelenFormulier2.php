<!doctype html>
<html>
	<head>
		<title>update artikelen formulier 2</title>
	</head>
	<body>
		<h1>update artikelen formulier 2</h1>
		
		<?php
			require "Artikelen.php";					// nodig om object te maken
			$artId = $_POST["artikelIdVak"];	// uitlezen vakje van deleteartikelenForm1 
			$artikelen1 = new artikelen();				// object aanmaken
			$artikelen1->searchArtikelen($artId);	
			// properties in variabelen zetten
			$artOmschrijving=$artikelen1->get_artOmschrijving();
			$artVoorraad=$artikelen1->get_artVoorraad();
            $artInkoop=$artikelen1->get_artInkoop();
			$artVerkoop=$artikelen1->get_artVerkoop();
			$artMinVoorraad=$artikelen1->get_artMinVoorraad();
            $artMaxVoorraad=$artikelen1->get_artMaxvoorraad();
            $artLocatie=$artikelen1->get_artLocatie();
			$artLevid=$artikelen1->get_levid();
			
		?>
		
		<form action="updateArtikelenFormulier3.php" method="post">
			<!-- $artId mag niet meer gewijzigd worden -->
			<br>
            <?php echo "artikel ID: " . $artId ?>
            <input type="hidden" name="artikelIdVak" value="<?php echo $artId;  ?> "><br>
			<label for="artOmschrijvingvak">artikel Omschrijving:</label>
            <input type="text"   name="artOmschrijvingVak"      value="<?php echo $artOmschrijving;     ?> "><br/>
			<label for="artInkoopVak">artikel Inkoop:</label>
			<input type="text"   name="artInkoopVak"  value="<?php echo $artInkoop;  ?> "><br/>
			<label for="artVerkoop">artikel Verkoop:</label>
            <input type="text"   name="artVerkoopVak"      value="<?php echo $artVerkoop;     ?> "><br/>
			<label for="artVoorraadvak">artikel Voorraad:</label>
            <input type="text"   name="artVoorraadVak"  value="<?php echo $artVoorraad;  ?> "><br/>
			<label for="artMinVoorraadvak">artikel MinVoorraad:</label>
            <input type="text"   name="artMinVoorraadVak" value="<?php echo $artMinVoorraad;  ?> "><br/>
            <label for="artMaxVoorraadvak">artikel MaxVoorraad:</label>
            <input type="text"   name="artMaxVoorraadVak" value="<?php echo $artMaxVoorraad;  ?> "><br/>
            <label for="artMinVoorraadvak">artikel locatie:</label>
            <input type="text"   name="artLocatieVak" value="<?php echo $artLocatie;  ?> "><br/>
			<label for="artLevid">artlediv:</label>
            
			<select id="artLevid" name="artLevidVak">
				<optgroup label="current">
					<option value=<?php echo $artLevid;  ?>> <?php echo $artLevid;  ?></option>;
				
				</optgroup>
				<optgroup label="options">
			<?php
			include "LeverancierConnect.php";

			$sql = "SELECT levid, levnaam FROM leveranciers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				echo "<option value='" . $row["levid"] . "'>" . $row["levid"] . " - ". $row["levnaam"] . "</option>";
				}
			} else {
				echo "geen leveranciers gevonden";
			}



			?>
				</optgroup>
			</select>




	



			<input type="submit"><br/><br/>
		</form>

		<a href="artikelenmenu.html">Terug naar het hoofdmenu</a>
	</body>	