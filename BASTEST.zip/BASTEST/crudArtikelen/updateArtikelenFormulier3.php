<!doctype html>
<html>
	
	<head>
		<title>update leverancier formulier 3</title>
	</head>
	<body>
		<h1>update leverancier formulier 3</h1>
		
		<?php
			require "Artikelen.php";

            // gegevens uit de array in variabelen stoppen
		    $artId = $_POST["artikelIdVak"];
			$artOmschrijving = $_POST["artOmschrijvingVak"];
			$artInkoop = $_POST["artInkoopVak"];
			$artVerkoop = $_POST["artVerkoopVak"];
            $artVoorraad = $_POST["artVoorraadVak"];
            $artMinVoorraad = $_POST["artMinVoorraadVak"];
            $artMaxVoorraad = $_POST["artMaxVoorraadVak"];
            $artLocatie = $_POST["artLocatieVak"];
            $artLevid = $_POST["artLevidVak"];
			
            
            // maken object ---------------------------------------------------
			$artikelen1 = new Artikelen($artOmschrijving, $artInkoop , $artVerkoop, $artVoorraad , $artMinVoorraad, $artMaxVoorraad, $artLocatie, $artLevid); // maakt object
			$artikelen1->updateartikelen($artId);		           // vervangt de tabelgegevens voor objectgegevens
            echo "Dit zijn de gewijzigde gegevens: <br/>";
            echo $artId."<br/>";
			$artikelen1->afdrukken();	                       // drukt object af

		?>
		<a href="artikelenmenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>