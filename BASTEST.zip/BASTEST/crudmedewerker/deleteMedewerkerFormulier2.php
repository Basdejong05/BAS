<!doctype html>
<html>
	<head>
		<title>delete Medewerker formulier 2</title>
	</head>
	<body>
		<h1>delete Medewerker formulier 2</h1>
		
		<?php
			require "Medewerker.php";					// nodig om object te maken
			$mwid = $_POST["mwidVak"];	// uitlezen vakje van deleteLeverancierForm1 
			$student1 = new Medewerker();				// object aanmaken
			$student1->searchmedewerker($mwid);
		?>
		
		<form action="deleteMedewerkerFormulier3.php" method="post">
			<!-- $mwid mag niet meer gewijzigd worden -->
			<input type="hidden" name="MedewerkerIdVak" value=" <?php echo $mwid ?> ">
			<!-- 2x verwijderBox om nee of ja door te kunnen geven -->
			<input type="hidden" 	name="verwijderBox" value="nee">			
			<input type="checkbox" 	name="verwijderBox" value="ja">
			<label for="verwijderBox"> Verwijder deze Medewerker.</label><br/><br/>
			<input type="submit"><br/><br/>
		</form>

		<a href="medewerkermenu.html">Terug naar het hoofdmenu</a>
	</body>	