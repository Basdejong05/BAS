<!doctype html>
<html>
<head>




</head>
<body>
<h1>Search Leverancier</h1>
<form action="searchLeverancierFormulier2.php" method="post">
    <label for="leverancierid">Leverancierid:</label>
    <input type="text" id="leverancierid" name="leverancierIdVak">
    <input type="submit">
</form>
<a href="leveranciermenu.html">Terug naar het hoofdmenu</a>









</body>

