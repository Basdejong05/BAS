<!doctype html>
<html>
<head>
    <title>Read leverancieren</title>
</head>
<body>
<h1>Read leverancieren</h1>
<p></p>

<?php
    require "Artikelen.php";
    $medewerker1 = new Artikelen();
    $medewerker1->readartikelen();



?>
<a href="artikelenmenu.html">Terug naar het hoofdmenu</a>
</body>








</html>