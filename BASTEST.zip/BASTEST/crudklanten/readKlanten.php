<!doctype html>
<html>
<head>
    <title>Read klanten</title>
</head>
<body>
<h1>Read klanten</h1>
<p></p>

<?php
    require "Klanten.php";
    $klant1 = new Klanten();
    $klant1->readKlanten();



?>
<a href="klantenmenu.html">Terug naar het hoofdmenu</a>
</body>








</html>