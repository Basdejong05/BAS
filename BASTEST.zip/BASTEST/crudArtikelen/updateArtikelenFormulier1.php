<!doctype html>
<html>
	<head>
		<title>update klanten Formulier 1</title>
	</head>
	<body>
		<h1>update klanten formulier 1</h1>
			<form action="updateArtikelenFormulier2.php" method="post">
			<label for="artikelId">artikelId:</label>
			

			<select id="artikelId" name="artikelIdVak">

			<?php
			include "LeverancierConnect.php";
			
			$sql = "SELECT artId, artOmschrijving FROM artikelen";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["artId"] . "'>" . $row["artId"] . " - ". $row["artOmschrijving"] . "</option>";
				}
			  } else {
				echo "geen artikelen gevonden";
			  }


			
			?>
			</select>

			<input type="submit">
		</form>
		<a href="schoolmenu.php"><br/>Terug naar het hoofdmenu</a>
	</body>
