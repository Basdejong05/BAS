<!doctype html>
<html>
<head>




</head>
<body>
<h1>Delete medewerks</h1>
<form action="deleteMedewerkerFormulier2.php" method="post">
    <label for="mwid">mwid:</label>
    <input type="submit">
    <select id="mwid" name="mwidVak">
    <?php
    
			include "LeverancierConnect.php";
			
			$sql = "SELECT mwid, mwNaam FROM medewerkers";
			$result = $conn->query($sql);

			if ($result->rowCount() > 0) {
				while($row = $result->fetch()) {
				  echo "<option value='" . $row["mwid"] . "'>" . $row["mwid"] . " - ". $row["mwNaam"] . "</option>";
				}
			  } else {
				echo "geen artikelen gevonden";
			  }


			
			?>
</form>









</body>













</html>