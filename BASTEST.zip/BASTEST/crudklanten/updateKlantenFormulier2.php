<!doctype html>
<html>
	<head>
		<title>update klanten formulier 2</title>
	</head>
	<body>
		<h1>update klanten formulier 2</h1>
		
		<?php
			require "Klanten.php";					// nodig om object te maken
			$klantid = $_POST["klantenIdVak"];	// uitlezen vakje van deleteklantenForm1 
			$klanten1 = new Klanten();				// object aanmaken
			$klanten1->searchKlanten($klantid);	
			// properties in variabelen zetten
			$naam=$klanten1->get_name();
			$postcode=$klanten1->get_postcode();
			$adres=$klanten1->get_adres();
			$woonplaats=$klanten1->get_woonplaats();
			$email=$klanten1->get_email();
		?>
		
		<form action="updateKlantenFormulier3.php" method="post">
			<!-- $klantid mag niet meer gewijzigd worden -->
			<br>
            <?php echo $klantid ?>
            <input type="hidden" name="klantenIdVak" value="<?php echo $klantid;  ?> "><br>
			<label for="klantnaamvak">Naam:</label>
            <input type="text"   name="klantnaamVak"      value="<?php echo $naam;     ?> "><br/>
			<label for="klantemailvak">Email:</label>
			<input type="text"   name="klantemailVak"  value="<?php echo $email;  ?> "><br/>
			<label for="klantadres">Adres:</label>
            <input type="text"   name="klantadresVak"      value="<?php echo $adres;     ?> "><br/>
			<label for="klantpostcodevak">Postcode:</label>
            <input type="text"   name="klantpostcodeVak"  value="<?php echo $postcode;  ?> "><br/>
			<label for="klantwoonplaatsvak">woonplaats:</label>
            <input type="text"   name="klantwoonplaatsVak" value="<?php echo $woonplaats;  ?> "><br/><br/>
			<input type="submit"><br/><br/>
		</form>

		<a href="klantenmenu.html">Terug naar het hoofdmenu</a>
	</body>	