<!doctype html>
<html>
	<head>
		<title>create klanten formulier 2</title>
	</head>
	<body>
		<h1>create klanten formulier 2</h1>

		<?php
			
			require "Medewerker.php";
			// uitlezen vakjes van createmedewerkerForm1 -----
			$naam=$_POST["naamvak"];
			$email=$_POST["emailvak"];
			$password=$_POST["passwordvak"];
			$status=$_POST["statusvak"];

			echo "<br/><br/>";
			
			// maken object -------------------------------
			$medewerker1 = new Medewerker($naam ,$email, $password, $status);
            $medewerker1->createMedewerker();

			// afdrukken object ---------------------------
			echo "<br/><br/>";
			echo $medewerker1->afdrukken();
			
		?> 	
		<br>
		<a href="medewerkermenu.html">Terug naar het hoofdmenu</a>
	</body>
</html>
